# Health Record — §10

Part of the health-record skill, read with `SKILL.md`, which every run reads first and which holds the opening, the table under *What you are probably being asked*, the rules every run owes, §0's *Every run leaves the record better organised than it found it*, §1, §11 and *Revising these rules*; its table of files says which file holds every other section. **Open this file when the table under *What you are probably being asked*, or a pointer, names a section it holds, and reopen it whenever a task needs it and its text is no longer in view.**

**This file holds** §10 Writing mechanics: *Dates are UTC* · *Check every schema before the first write* · *Mentions, and why a SQL query lies* · *Reading a whole table* · *Links that go nowhere* · *Two tags that look alike, and only one of them is a link* · *What else the connector offers, and what is done with it* · *Writing a synced relation across many rows* · *Fetch before writing* · *Updating an existing row* · *Order of writes* · *Row page content* · *The verification callout* · *After writing*.

Sections by file: `SKILL.md` — the opening, the table under *What you are probably being asked*, the rules every run owes, §0's upkeep, §1 and §11, and *Revising these rules*; `references/menu.md` — §0's opening paragraphs and the menu; `references/items.md` — §0's numbered items, *Before any of this has ever been run*, *When a heavy pass is actually due*; `references/record.md` — §2; `references/buying.md` — §3, §4; `references/evaluating.md` — §5, §6; `references/research.md` — §7's *Finding what exists*, *Substance-level against product-level*, *Writing a page*, *Editing an existing page*, *What the record never holds*, *A page's own note to these rules*, *Grading `Evidence`, and the citations under it*, *How much of each source was read* and *Recording a compounded or made-to-order product*, and §8; `references/changes.md` — §7's *Consolidating pages*, *Revisions: the chain of edits*, *What each kind of change makes possibly wrong*, *A correction does not stop at the page it fixes* and *Classify before writing*; `references/sweeps.md` — §9; `references/writing.md` — §10.

---

## §10 Writing mechanics

### Dates are UTC

**Every date that records a run's own act is the UTC date at the moment of writing** — a `Revisions` entry, an `Edits` line, a note on the queue, `Last looked at`, the scoreboard's dates, a callout's date — after midnight UTC included, even within a sitting that began the day before. Notion's own created and last-edited times are its own and never written (*Reading a whole table*, below).

### Check every schema before the first write

Everything hard-coded here — property names, select options, database identifiers — was read from the live databases and can drift. **Fetch the schemas once before the first write of a run.** Reads can proceed on what is written here, a rows-mode filter or sort excepted, whose names the connector rules take from the fetched schema; writes cannot. The fetched schema always wins, the queue's `Kind` options excepted (§2, the queue).

**Work around it and name it in the report:** a property renamed (match by role), a property added (read its description, use it where its role is clear), an option renamed or added (use what is there), an option this document expects that is gone and unneeded this run.

**Stop and ask, before writing anything that depends on it:** a property this skill writes to has vanished or changed type; two properties now plausibly fill one role, so matching by role would be a guess; a select or multi-select has lost an option this document names and this run needs — **an option that has gone is a removal somebody made, not a gap to fill, so it is asked about rather than added back** (§1).

Say three things, then ask one: what was expected, what the database has, and what each way forward costs. **Never invent a property, guess between two plausible matches, or write a field whose meaning could not be established** — and never add an option to paper over a value you could not place, which is that same error wearing the permission of §1. A field left unwritten with the mismatch named is recoverable; a field written into the wrong property is not. **No mode suspends this**, including a run told to stop asking — a run that cannot establish where a value goes stops and says so.

**Adding an option is the one change this skill makes to an existing schema (§1).** **A `Works For` option is added on every table that carries the field** (§2, *The `Works For` vocabulary*), **and a purpose on all four verdict lists of the buying table** (§4, *The purposes a product is judged for*), each of those lists being a property of its own, in one schema change, and each list is changed the way the connector rules change one. **A property's description is never changed here**: one that has fallen behind these rules is named in the report as a correction for the user to make.

**No property appears in a Health table by accident.** A table under Health — the four, the working tables beside them, or a table inside a page — gains a property only when the work calls for that property by name, and nothing in this skill does (§1). **Every relation under Health is one-way, the pairs that already exist excepted**: where a link back is wanted it goes in a text property holding mentions, as `Research Pages` does, and a relation the user asks for is theirs to add, one-way (§1). **After any schema change, check every table it touched as the connector rules check a schema change, against the schema fetched before**: a property nobody named is reported, never written into, and left for the user to remove.

### Mentions, and why a SQL query lies

**Two kinds of link exist here and they behave oppositely. Never apply one's rules to the other.**

`Research Pages` and `Can be acquired without a prescription in one or more countries` (Buying Decisions & Info), `Related Pages` (Meta) and `Where` (the queue) are **text properties holding inline page mentions**, not relations. **They are read, and written back, only the way the connector rules handle text holding mentions.** That is also why a SQL query lies about them: every mention in them but `Where` carries a parenthetical, so in a SQL read every row looks filled whether or not its links are there, and a link check run there reports every row already linked.

`Sources` and its synced twin `Source For`, `Must Agree With` with its twin `Named By`, and `Child of` with its twin `Parent of`, are **true relations**: written as page identifiers rather than as mention markup, with no `; ` separator and no parenthetical (*Writing a synced relation across many rows*, below). **Lists and whole-value text are written the way the connector rules write them** — the relations; the multi-selects, `Works For` on Health Pages, Dose, Form and Timing, Meta and the queue (§2), and `Availability` and the four verdict lists on Buying Decisions & Info; and every text field that has to keep what it holds, `Substances / Topics`, `Why`, `Edits` and `Evidence / Receipt` among them.

Write each mention in a field holding mentions in the form the connector rules give for a page mention, its URL being the target page's own, consecutive mentions joined with **the separator that row is already using**, and `; ` where it has none. `Research Pages` is uniform on `; `; `Related Pages` on Meta is mixed, most rows on `; ` and about ten on ` · `. Both are correct, the rule is per row rather than per database, and the field is read before anything is appended to it. Anything else written there — a page title typed as text, say — reads as a filled field that holds no mention (the connector rules say which forms store as a mention).

**Every mention in those fields but `Where` carries a parenthetical saying what that page holds for this row**, in Buying Decisions & Info as well as in Meta. A bare list of links makes a later reader open all of them to find the one that matters; *(the molar arithmetic, and how common the pairing is)* makes the field usable without opening anything. Where a mention is copied from an index rather than written fresh, the index's own parenthetical is the one to carry over — it was written by someone who had the page open.

**A row must never mention itself.** It reads as a filled cross-reference and resolves to nothing, and it arrives mechanically: an index that lists a product's own page among a substance's sources will hand it straight back when that index is used to rebuild the row. Drop the row's own identifier from any set of mentions before writing. **In `Can be acquired without a prescription in one or more countries`, evidence that sits in the row's own body is written *(this row's page)*, never as a mention.**

**Finding the rows that cover a given page, and finding rows whose link is missing, are both runnable in bulk** — one read of the whole table, past its row limit where it has one (*Reading a whole table*, below) — never a fetch per row.

### Reading a whole table

**Health Pages — which the flattening more than doubled (§2, *Every research page is a row*) — and Buying Decisions & Info are well past a read's row limit, and any table may reach it**: take the count first, read every row by the connector rules' routes past the limit, and hold what came back against the count.

**`Created time` by month is the partition that works on both large tables**: every row falls in exactly one month. Health Pages' months are uneven — each page the flattening moved up brought its own `Created time` (§2) — so read the month distribution against the row limit before the first batch and split any month that approaches it. **No other property partitions Buying Decisions & Info that a pass can rely on**: `Met Intended Purpose` is the old verdict, blank on every row but the products still carrying it, `Decision` is emptied on each product row as it takes the new verdict (§4, *The old verdict, until every product carries the new one*), `Item Type` has one option holding most of the rows, `Availability` is a multi-select, and `Last edited time` moves under a pass that writes. **Its view called Shortlist carries no filter**, and paging it is the other route through the whole table; read the view's configuration first.

**The timestamps are Notion's own and are never written:**

| Table | Creation | Last edit |
|---|---|---|
| Health Pages | `Created time` | `Last edited time` |
| Dose, Form and Timing | `Created time` | `Last edited time` |
| Health Pages - Meta | `Logged` | `Last edited time` |
| Buying Decisions & Info | `Created time` | `Last edited time` |
| Outstanding Work | `Logged` | `Last edited time` |
| What Maintenance Has Been Run | `Created time` | `Last edited time` |

Never include one in a write, and never treat a value that looks wrong as something to correct. **Their values are true history back to each row's creation**, not the day the property was added. **A last-edited scope is a sort on the table's `Last edited time`** — newest first for *what changed since* (§0, item 4), oldest first for *untouched since* (§0, item 15) — cut at the date asked for, never a search. The connector rules say how to tell apart two changes made on one day, and which kinds of change leave the time where it was; a report resting on a last-edited scope names those kinds as unseen. **`Created time` and `Logged` scope creation the same way**, which is what makes item 16's age check on the Absences a filter (§9).

### Links that go nowhere

**A cross-reference written into a page body points at a section in words, never with a link to a heading.** **Some pages of the record hold what a body write drops** — a malformed link already on the page, most often one aimed at a heading, and the fill-in blanks some pages carry for the user to complete by hand — so every body write takes the check the connector rules give for what a re-parse drops, and a blank that went is put back in the same sitting. **A dropped link is reported under what was written — the words stayed, the links went, and they went nowhere — never as damage**, because calling it destruction sends the user to their version history for nothing. **A heading link's slug names the section the author meant**, and once the link is gone nothing says where the words pointed: where one sits inside the passage you were already replacing, say in words what it pointed at; elsewhere on the page, count them and report the count rather than opening passages you were not editing.

### Two tags that look alike, and only one of them is a link

**A page's body can carry two things that both render as a page link, and they are not the same object**: a sub-page is the page itself, sitting beneath this one, and a mention is a pointer to a page that lives somewhere else; the connector rules give the tag a fetched body shows for each. **Never write a sub-page's tag, and never compose a replacement for a passage that contains one** — the connector rules say what either does — so a mention is what goes into a body to point at a page, and a passage holding a sub-page's tag is edited around, by the smallest-passage rule, never through. The move tool (§2, *A page found beneath a row comes up*) is the one way a page changes parent under these rules, and it goes one direction: up.

### What else the connector offers, and what is done with it

**Nothing on this list is done against this record beyond what its entry allows.** Creating a page, writing a property, editing a body, querying, searching and fetching are the rest of this section's subject, and the move tool is §2's (*A page found beneath a row comes up*); none of them is repeated here.

- **A page is never duplicated.** The tool exists and it is the fastest route to two pages stating the same claim at the same scope, both looking complete, each findable by a different search (§7, *Writing a page*; §0, item 18). **And it is irreversible here, because undoing it is a deletion** (§1, the first of the four). A page that should carry what another holds is **grown** — a consolidation, which destroys nothing (§7, *Consolidating pages*) — never copied. A page the user wants as a fresh start is created empty as a row and written (§7).
- **A view is read or created, and an existing one is never changed.** **Changing a view, or changing which view a table opens on, changes what the user sees when they open that table**, and that is theirs.
- **A comment is not part of the record, and nothing here writes one** — any run that later read it would take it for the user's own words. A comment is looked for by no later run, so a finding left in one is a finding lost: it belongs on the page, in Meta (§8), or on the queue (§2). **Where a comment is read** — the user points at one, or one sits on a page already open — **what it holds is the user's own words**: quote it, attribute it to them with the date, and never write it into the record as something the record says.
- **A file is attached in one case only.** The user put it in this chat as the receipt for a change they asked for or for a row written from it (§5, *Photographs and unidentified products*), and it goes onto the page or row that change landed on, **beside the transcription rather than instead of it** — a label photograph, a screenshot of a listing, a leaflet. The attachment is what turns *the label said* into something a later run can open, and **the report names where it landed** — a file added beside a transcription adds information and moves no verdict, so it earns no `Edits` line of its own (*Updating an existing row*, below); where the change it accompanies earns one anyway, that line names it. Nothing here removes an attachment afterwards. **A file a chat attached to a queue row, for something the user was shown that had no page or row to go on yet, is that same receipt waiting for a row** (§2, the queue): it goes onto the row with the transcription (§7, *What each kind of change makes possibly wrong*), and is read like any other file on a row meanwhile.
- **A file already sitting on a page or row of the four databases is opened and read like anything else on that page, and it is evidence** — a label photograph, a lot certificate, a leaflet somebody attached. That is one way §5's evaluation floor can be met without asking the user for anything. Cite it as the page and the date it was attached, that being the only handle it has, and say in the report that the document came off the record rather than off the maker's site, since the two decay differently. **Never one on a row ticked `Ignore`** as a ground (§2).
- **A database is never renamed, and neither is a data source.** Every recovery path in this document runs through a title: a failed identifier is answered by searching the workspace for a database called `Outstanding Work`, `What Maintenance Has Been Run` or Health Skills — Standing Instructions and Fixes (§2), and the scoreboard is never written to under any other title. A rename breaks all of that silently, and the run that meets the breakage afterwards cannot tell a renamed table from a deleted one. The same holds for the four record databases, whose names this document uses throughout. Name the rename you would make in the report. **The buying table was renamed once, by the user, on 2026-09-16, from Supplement Decisions; its identifier did not change, so search either title when an identifier fails.** **Nor is the Health Pages - Meta data source ever replaced, or moved to another database** (§1, the first of the four), **and where the user means to do either themselves, tell them first that a page outside the record depends on it.**
- **No agent or session is spawned inside Notion.** An agent set running in the workspace is the case *Fetch before writing*, below, tells a run to stop for — a page whose last-edited time keeps moving for reasons that are not its own. **This is about the workspace's own agent machinery and nothing else.** The parallel sub-agents §6, *Delegating the research, which is how six at a time becomes four times that* permits are a different thing entirely and are unaffected: they run outside the workspace, they read the record through the ordinary tools, and they never write to it.
- **A bulk creation of several pages in one call does not escape the two-call description rule** (§2): each new Health Page is still created without its `Description`, given one in a second call, and read back. Where a bulk call is used, the second calls are one per page, and **every page's description is read back — in one read over the batch, not one fetch per page** (*After writing*, below). The saving is in the creation, not in the writing of the descriptions: a batch created and described in the same call is a batch findable by wording nobody chose.
- **A field is emptied only where the user asked for it or the run established that it should be, and the clearing is named** — **and a relation or a multi-select only where a receipt allows it**: an entry comes out of a relation only in the stand-in swap (§2, *A page found beneath a row comes up*, step 8), in pointing away from a row the user ticked `Ignore` (§2, *`Ignore` is the user's flag, exactly as `Current` is*), and in pointing at the part of a split page that now holds a passage (§2, *Every research page is a row*); and a multi-select is added to and never subtracted from (§7, *Consolidating pages*), the four verdict lists of a product excepted, which move with its verdict (§4, *A product's verdict*). *Absence from this pass means preserve, never clear* is the rule for everything a pass did not look at (*Updating an existing row*, below); this is its other half, for a text or select field a pass did look at. A value removed leaves no trace of itself in any property, so the `Edits` line or the `Revisions` entry is the only record that it was ever there, and a field cleared without one reads afterwards as a field nobody ever filled. `Price Per Amount` is the exception, since the price it restates stays on the row (§3, *`Price Per Amount`*).

**And settled elsewhere:** nothing here deletes or archives anything, whatever the user says — the act stays available to the user (§1, the first of the four).

### Writing a synced relation across many rows

`Must Agree With`, `Sources` and `Child of` each have a synced twin (§2) — `Named By`, `Source For` and `Parent of` — filled from the other side. **Write each edge once, from one side only**: writing both sides rewrites each list twice for nothing. **`Sources` and `Child of` each have an owning side — the spec row, the page — and are written from it whatever the count of edges** (§2). **On `Must Agree With`, write from whichever side takes fewer calls**: the page with the most unwritten edges first, all of them in one write, then the next — the connector rules give the limit on one write and the checks a batch of them owes.

**Take an answer from the side that owns it**, as the connector rules take one from a two-way relation. So read a page's dependants from the `Sources` of the rows you open, not from `Source For`; count edges from the outgoing side; and check any entry on an incoming side against the page it names before acting on it.

**The report carries each relation's entry count from before the first write and after the last**: the first taken from the read each relation write needs anyway, the second worked out from what the run wrote and labelled in the report as written, not re-read; the checks a relation write owes are the connector rules'. The first is what turns *nothing could have been silently replaced* from an assumption into a fact.

### Fetch before writing

**Fetch the page immediately before writing to it,** and build the change against what comes back (the connector rules on a write built from an earlier read). If the row moved since you read it, work from the new state and fetch again before writing. If the new state leaves a choice you cannot settle, leave the row alone, say so, and put the change on the queue as below. **And where it has moved twice while you were rebuilding for reasons that were not your own writes — discount your own moves first, then count what is left — someone else is in that page: another chat, the workspace automation, or the user editing it in Notion. Stop, leave it alone, and say so in the report** — retrying against a page somebody else is writing has no end, and two revision lines appended in the same minute cannot be told apart afterwards. **Then put the abandoned change on the queue** (§2), carrying it in full in `What changed` at the weight it costs, under the kind the change itself would have taken, or `asked for not done` where the user asked for it — **or, where the row this run was clearing is still open, appended to that one rather than a second being opened**: the report is read once and the change was real. **Keep the last-edited time from the fetch you built against and compare it in the fetch immediately before the write**; that comparison is how *the row moved* is established.

**Read its `Revisions` section, or its `Edits`, and its `By hand` flag, in that same fetch** (§7, §2). The fetch is already paid for, and it is the last moment at which a run can discover that the conclusion it is about to write is one this page has already abandoned. The flag says whether the row is one the user added by hand and nothing has brought in yet (§2, *`By hand`*).

**Where the connector rules let a write go without a fetch of its own, say in the report that you skipped it and why** — and a page this run created still takes one before any write that touches a mention-bearing field.

**A batch that touches a verdict or a specification — a product's lists, box or `Dose check`, a `Decision`, a `Why`, a `Form`, a `Dose Range`, an `Evidence` grade — reads each row's chain in the read its new values are built from, and checks every row against it before its new value is built**: `Edits` on Buying Decisions & Info, which that read returns; a spec row's chain is in its body, so spec rows are never bulk-written. A `Works For` tag, a description, an alias list or a link carries no claim in this sense, and a batch confined to those needs no chain read. Without it the batch quietly removes the only revert check there is (§7, *Revisions: the chain of edits*; *Updating an existing row*, below), so a batch that cannot show it read the chain is a batch confined to fields that carry no claim.

**On a batch, keep the worklist the way the connector rules keep one — and item 12's is always a file**, since its purpose tag leaves some rows rightly unfilled and the query that built the worklist goes on returning them: a row examined and left blank is appended to the file like any other (§0, item 12).

**A drafted edit is applied to the live row, never to the copy it was drafted against.** Before applying find-and-replace edits drafted elsewhere — in a file, in a queue row, by an earlier chat — read the live row; apply each replacement only where its anchor, in the form the connector rules give for an anchor, occurs exactly once; and report an anchor that is missing as already applied or superseded, never forcing the write.

**Replace the smallest passage that must change**, not the section containing it: a paragraph added from outside is not in your copy, so it is not in your replacement, and it is gone.

### Updating an existing row

Update in place. History lives in `Edits`, not in duplicate rows: append a dated `YYYY-MM-DD:` line saying what changed and why, keeping earlier entries, save to take out a limit (§7, *What the record never holds*).

**A line that moves a verdict or withdraws a ground states what it moved from**, in the same shape the `Revisions` section uses (§7): *what it says now · was: what it said before · because: the receipt · set aside: the sources weighed and not followed, and why*. **The `set aside:` part is written here for the same reason it is written there** — §7's revert check reads `because:` and `set aside:` together, and an `Edits` chain with no such field takes the no-`set aside:` branch of that check for ever, which is a weaker test than the row deserves. `Edits` is this database's revision chain and it does the same job — **before writing a verdict, read it and check whether it is one this row has already moved away from.** Where it is, the revert rule in §7, *Revisions: the chain of edits*, applies unchanged. A row carrying `Edits` needs no `Revisions` section in its body; the two are the same mechanism and writing both splits the chain.

**`Edits` exists only on Buying Decisions & Info.** **A spec row's chain lives in the `Revisions` section of its body instead** (§7), which is why the body template below carries one: the row's *properties* read as what is currently true, and the history of why they moved sits underneath them rather than in them.

**`Edits` records why a judgement moved, not that a field was touched.** A change that alters a verdict, withdraws a ground, corrects a fact or changes what the row recommends earns its line, and so does the *by hand* line that bringing a row in writes (§2, *`By hand`*). A purely mechanical repair that **adds information, removes none, and moves no verdict** — repairing links across a batch, adding an alias, normalising a format, writing or emptying `Price Per Amount` (§3, *`Price Per Amount`*) — does not, and appending a hundred identical lines buries the entries that matter under ones that never will. The record of that work is the report, and on a sweep it is the sweep's own table of every row in scope (§9). If it is not obvious which kind a change is, ask whether a later reader deciding what to buy would want it: that is what `Edits` is for.

**Write only what you re-examined.** Every property and page section you did not look at carries through unchanged. **Absence from this pass means preserve, never clear** — a field goes empty only when you established it should, and the clearing is named in `Edits`, `Price Per Amount` excepted (§3, *`Price Per Amount`*). The page-body template is the shape of a *new* row; on an update it is sections to patch, never a page to replace.

**Changing `Intended Purpose` obliges re-deriving the four lists and `Why For Purpose` in the same pass**, along with any purpose-dependent sentence in `Why`, re-ordered so the deciding criterion still comes first (§3). All are computed against a purpose and none survives a change of one; dose arithmetic preserved under a purpose it was never computed for is worse than a blank.

**A product row still on the old verdict gets the new one in the write that next judges it** (§4, *The old verdict, until every product carries the new one*): its lists, its box and its `Dose check` written, `Decision` and `Met Intended Purpose` emptied — save where §4 leaves a user's own old values standing — and its `Edits` line saying what those two held and, where the write carries across a verdict of the user's own, that the user set it.

**Any change to a product's verdict obliges rewriting the `Why` and `Why For Purpose` it was written on, and re-reading whatever else rested on the same fact.** A `Why` left standing under a moved verdict argues for the verdict the row no longer carries, which is what §9 sweeps for. The box and the lists answer different questions and usually move apart (§4, *Rules that hold across the lists*) — but where both were written on one fact, correcting one leaves the other standing on nothing. Ask what fact each was written on; where the change touched it, re-derive both.

**When a specification moves, the rows that were judged against it are not all found through their citations.** A row that should cite the spec row and does not is a known defect (§0, item 14), so after a `Form` or `Dose Range` change also search Buying Decisions & Info on `Item` and `Why` for the substance and each of its forms — the route a brand change uses, below — and treat every hit as a row to re-derive or to name as skipped and put on the queue (§2).

**When a corrected Health Page was cited, every row citing it inherits the correction.** Searching for a brand or substance name does not find them, because the citation lives in `Research Pages` or in `Can be acquired without a prescription in one or more countries` (*Mentions, and why a SQL query lies*, in this section). Read both fields across the affected rows — the whole table, as *Reading a whole table*, above, reads it — or say the check was skipped and put it on the queue (§2). **The spec rows resting on that page inherit it too, and `Source For` names candidates without a query** — each verified against its own `Sources` before it is acted on (*Writing a synced relation across many rows*, above). Do that half first; it is also the half most likely to matter, because a wrong specification propagates into every verdict judged against it. **A corrected page sitting above rows that still argue from its old claim is the worst state this workspace can reach** — the record contradicts itself, and nothing on either side says which half is current.

**When a brand row's `Decision` changes, its supplements change with it**: on a move to `Bad`, each whose own dose is not independently confirmed takes the box; on a move back, the box comes off where the brand was its only ground (§4, *On a brand row*). Search `Item` **and** `Why` for the brand name, and name every affected row in the report, as a change made or an explicit skip, the skips going on the queue (§2). `Why` matters as much as `Item`: a house label carries the maker's name nowhere in its title, nor does a listing titled before listing titles carried the maker, and a product row has no brand property to find it by.

**When a product's verdict changes, every other row of the same product, listings included, changes with it.** Listings share the product's verdict (§4), so moving one and leaving the others is how a table comes to hold two answers to one question — a listing whose `Why` carries a documented fact about its own channel, or a gap about what the product is, keeping what that fact or gap moved on it (§4, *On a listing, the verdict is the product's*) unless a re-read against the new verdict finds it no longer holds. **Find them by searching `Item` for the product name** — the listing titles all carry it, which is what that title pattern is for (§3) — and move each one that is this product's, as its title shows or, where a title written before listing titles carried the maker leaves that open, its `Why` or its page does, naming the set in the report.

**When a seller's `Decision` becomes `Bad`** — the user's own, or a documented reputation for underdosed or fake products (§4, *On a seller*) — **re-read the listing rows at that seller and change them only for a channel fact.** **Find them by searching `Item` for the seller's name.** A medicine's listing there is named in the report for the user to delete and takes the deletion marker (§1), medicines getting no listing rows at such a seller (§3, *The kinds of row*). A seller going Bad does not make the product bad; what it can do is supply the documented channel fact that ticks the box on a listing (§4, *On a listing, the verdict is the product's*). So: read each listing, ask whether that reputation is a reason to doubt *that* purchase, and move only the ones where it is — every supplement listed there whose own dose is not independently confirmed, where independent testing documents the under-dosing (§4, *On a seller*). **Say in the report how many were read and how many moved**, because "none moved" is a result and an unexplained silence is not.

**When your own earlier reasoning was wrong, correct it and say so in `Edits`.** A verdict resting on two grounds where one does not hold gets rewritten to rest on the one that does, with `Edits` naming what was withdrawn. This extends to advice given earlier in the same conversation: say plainly in the report what was wrong, then **rewrite the row so it reads as though it was always right**.

**A correction made in the run that created the row leaves `Edits` blank**, and this is the more specific rule where it meets the one above: a row created and corrected in the same run gets no line, even where the correction was to this skill's own earlier reasoning. `Edits` logs what changed after creation, and a row rewritten before anyone else has read it was never in its earlier state as far as the record is concerned. The correction still goes in the report. From the next run onward, every correction gets its dated line; a run is one request in one chat, up to its report, and the same holds for its own text elsewhere in the record (§7, *Revisions: the chain of edits*).

**On a row the user entered or changed by hand** — still ticked, or carrying the *by hand* line bringing it in writes (§2, *`By hand`*) — **a verdict they set is theirs as a fact** and moves by the ordinary rules: not against evidence that has not changed, which stops and asks (§1, the third of the four); and where the evidence has moved, moved and reported like any other.

**When the user asks what a verdict rests on, go and look before answering.** "Why is that a problem?" and "what are you reading to conclude that?" are requests for the ground, not disagreements, and they are the cheapest audit available. Re-open the source, quote the operative clause, and compare it against what the row claims. Two failures sit either side of this: defending a verdict because it was written confidently, and abandoning a sound one because the question sounded certain. Neither is available once the passage is on the screen. Where the ground holds, say so and quote it; where it does not, the correction is the answer, and it fans out to every row and page that argued from the same claim (§7, *A correction does not stop at the page it fixes*).

**When the user states a general principle this document does not carry, adopt it and say it belongs here.** The rules in this file were derived from cases, and the user has more cases than any one of them. A principle offered in passing — how to weigh an added ingredient, what counts as a defect, which axis decides — applies from that moment to the run in hand, and it is worth more than the correction that occasioned it, because it generalises. Name it plainly in the report as a rule that should be added, and ask whether it is to hold from now on — their yes is what records it as a standing instruction (§2, *🛠️ Health Skills — Standing Instructions and Fixes*).

**When the user disagrees:** they have found an error — fix it, say what was wrong, record it, and do not soften the correction into partial agreement. They want a different verdict and the reasoning still stands — say so once with the reason, then record what they decide. A row carrying the verdict they preferred, with `Edits` recording exactly that, is honest; one talked down without new evidence is not.

### Order of writes

**Health Pages first, then Dose, Form and Timing, then Meta, then Buying Decisions & Info, and the counts appended to What Maintenance Has Been Run last of all** — the queue row naming a pass's scope is written before its first write, which is a different edit and is covered in the paragraph below. Each layer points at the one before it: a spec row's `Sources` needs its pages to exist, a Meta row's `Related Pages` needs whatever it bears on, and a product row's `Research Pages` needs its target's URL. None of those exists until the target is written. Where a page could not be created, leave it out of `Research Pages`, name the outstanding link **in the report** and put it on the queue (*Fetch before writing*, above) — **never type a page title as text in its place**, which looks like a link and is not one, and **never hold the product row for it**, since the verdict does not depend on the link.

**A band C or D pass — or item 20 on a tier holding a `Whole table` row, or item 22 where it reaches a whole table (§0) — writes one queue row naming its scope, under `pass in progress` at `Whole table` and `Open`, before its first write — or, where a row an earlier run left open is that same scope, takes that one up rather than opening a second (§0), and appends its counts to the scoreboard after the report, item 22 on the condition §0 puts on it** (§2, §0) — a run that writes nothing but its counts, item 21 finishing a clean table in one sitting above all, opens none: the scope row exists to survive an interruption between writes to the record, and a counts append is one write, made last. Opening the row costs one write: a pass that dies half-way leaves it standing, saying what was in scope and what had been reached, and the next run of that item finds it by querying `Left by`. **Rewrite that row's `What would clear it` at the end of each group of writes, naming the last unit finished** — that one edit is the whole reason the row is worth having, since nothing else records how far a pass got, and a pass that dies leaves it saying only what was in scope otherwise. A pass that reached the whole of its scope sets it `Done`; one that finished part of it sets `Examined not cleared` with that line current, which is the commoner outcome and keeps it findable, that status being outstanding work like any other (§2). **A pass that ends without doing either is a pass the next run will repeat**, so where that write fails, say so in the reply — the counts, and the status on that row, are what is scheduled after the report, and nothing else will report them.

### Row page content

Property values are the summary; the body carries the working.

```
## Verdict
[On a product, each purpose's list and the one criterion that
put it there, the box and why, and Dose check and what it rests
on. On a brand or a tool, the decision and its criterion.]

## Checklist
[Section by section. What was skipped, and what came from the
recorded research rather than fresh work.]

## How to take it
[Timing, food, splitting, storage, separation from minerals.]

## What would change this
[Required where the box is ticked, where a purpose sits on
Might work for, on a brand at Bad, and on a tool at Bad or
Needs More Research. Elsewhere, what would move a purpose.
Name any part of the evaluation floor you could not reach.]

## Sources
[Product page, plus every research link that informed the verdict,
each with how much of it was read (§7, *How much of each source
was read*).]

Researched YYYY-MM-DD.
```

The product URL goes under Sources — there is no property for it. **A brand row's body** drops *How to take it* and carries the manufacturer record and its sources instead.

**A device or a supply uses *How to use it* in place of *How to take it*.** Everything else in the template holds, and every kind's body opens with the verification callout where the run wrote or checked it (*The verification callout*, below).

**The other kinds have their own shapes, and every one of them ends with the same closing line.**

- **Seller:** `## What it sells and how` (prescription handling, delivery, shipping thresholds, whether stock is visible before ordering) · `## Sources` — and, only where one is recorded, `## Reputation for underdosed or fake products`, with its evidence. No verdict, no trust signals and no *What would change this* (§4, *On a seller*).
- **Tool:** `## Verdict` · `## How to use it` · `## Limits` · `## What would change this` · `## Sources`.
- **Access rule:** `## What the rule is` · `## How it shows at the point of buying` · `## What to watch for` · `## Sources` — and the re-check date.

**Every kind's body ends with `Researched YYYY-MM-DD.`, dated the day of the write.** That line is one of the things the third of §1's four tests on. **Where nothing new was searched, the line still goes in and the body says so** — *From the recorded research: <page title>; nothing new was searched except …* — because "researched" there means the work was done, not that the web was opened.

**A spec row's body is a different shape**, because its properties already carry the specification. The body holds only what they cannot:

```
[What the range rests on, where that needs more than the
 Dose Range field holds: which protocol, which population,
 why two figures are both kept.]

[Any unsettled Meta row the specification sits on — a contested
 figure, an assumption, a correction against the page under it —
 named with the row that records it.]

[The purpose it serves, where the shared tag list has no option for it
 (§2).]

[What the specification does NOT establish.]

Researched YYYY-MM-DD.

## Awaiting logging
[The user's own wording, moved here whole out of a field that has to
 carry the research (§2, *The user's own use is out of bounds*). Added
 to, never otherwise rewritten. Absent until the first such move, and
 gone once its last note is in the user's own history.]

## Revisions
[Appended for whatever earns a line (§7, *Revisions: the chain of
 edits*). Absent until the first one.]
```

**Never restate a property in a spec row's body outside its `Revisions` section**, where saying what a value moved to and from is the point, and its *Awaiting logging* section — on an older row, under a longer heading that begins with those words — which holds wording no property carries. The sentence recording a stand-in in `Sources`, and later its swap, is kept in the body as well (§2, *A page found beneath a row comes up*, step 8). A body repeating the `Form` field elsewhere is how the two start to disagree.

### The verification callout

**A run that checks a page's content against its sources, or writes or rewrites the page, puts a callout as the first block of its body saying so** — on research pages, substance lines, Meta rows and every kind of buying-table row alike, and **never on a row ticked `Ignore`**.

- **A whole page** — written whole, or checked end to end — gets a green callout (🔎, green background) opening in bold with the scope, the date, the model and its effort: *AI-researched, whole page — YYYY-MM-DD — \<model> on \<effort> effort.* for a page written whole, *AI-checked, whole page — …* for one checked end to end, and *whole row* for *whole page* on a substance line, a Meta row or a buying-table row. Then what it was checked against; *Not established:* for facts no source settled; and when a later run needs to look again.
- **Part of a page** gets a yellow callout (🔎, yellow background) opening *AI-checked, part of this page — …* or *most of this page*, then *Checked against primary sources on this date:* naming the parts and their sources, then *Not checked:* naming the rest.

**A page carries one such callout.** A later check updates it in place — widening its scope, turning it green when nothing is left unchecked, updating the date and the model — and keeps what an earlier, fuller check said where its own covered less, save for parts edited since that check, which it lists as not checked. **A later run trusts a callout dated on or after the page's last real edit**, and re-checks only what it lists as not checked or says is now due for another look, plus prices and stock; an edit after that date voids it for the parts edited. **A page without one has not been checked or written by a run since 2026-10-01**, may be old, and may hold mistakes or poor recommendations: it counts as never verified and ranks first for checking, oldest first. **Only what the run compared against a source counts**: a mechanical edit earns no callout, and the callout is not a change log — a check still makes the change note these rules ask for. It sits above everything *Row page content*, above, lays out, with a page's own note to these rules directly beneath it (§7, *A page's own note to these rules*).

### After writing

**Do not let a write and its verification race** — the `Description` second call and its read-back most of all: the read-back waits until the write has landed, and reads by a route the connector rules say shows it at once.

**Confirm the write landed where the connector rules owe a check**, and in particular that inline mentions landed as mentions rather than as text — read back the way the connector rules read text holding mentions. Check the separators between consecutive mentions while you are there, **matching whichever that row uses** — a missing separator is the defect, a differing one is not — since they go missing when a field is appended to incrementally. Where a mention landed as text, rewrite the property and say so. **Never leave text that only looks like a link.**

**Check link integrity while you are there.** A mention whose page has been deleted is dead, and it is owed what anything noticed and not fixed is owed (§0, *Every run leaves the record better organised than it found it*) even when it is not this run's to fix.

**Expect your own writes back in a slightly different form** (the connector rules say how), **and do not flag the difference as a failure.** **This is a rule about normalisation, not about content.** Normalisation preserves every word; a `Description` that comes back saying something else has been *replaced*, not normalised, and the read-back below is right to rewrite it. Compare the words, not the markup.

**Read `Description` back after writing it, and write it again if what comes back is not what was sent** (§2; a change on *update* is also a Meta row, §8) — on a newly created page after the second call, and **on an updated page too, above all where a pass is writing descriptions in bulk**: the overwrite is recorded as a creation-time behaviour, an on-update version is contemplated in §2 and unverified, and a bulk re-read verifying *was this field empty* passes a clobbered description without noticing. One read over the batch reads back every description in it, past the row limit where the batch is past it (*Reading a whole table*, above), and settles it for the whole pass — that is the read-back, and it is not a fetch per page (*What else the connector offers, and what is done with it*, above). Until that read-back has run, the description a later search matches on is not established. This failure is completely silent: the page looks finished and is merely findable by the wrong words. The check is owed on every new page regardless of what is believed about the workspace's automations — it is a read-back, not a workaround for one of them.

**Say in the report which claim you are making: written, or verified.** Only re-running the check that motivated the writes (below) verifies them, and only it can report how many rows are still wrong. The two read identically in a report and are not the same claim, so name the one you actually have, and where it is the second, give the number that came back rather than the number you sent.

**Verify against the condition that defined the work, not against the field being filled.** These come apart, and the weaker check passes exactly the rows that are still broken. A repair whose purpose was *every row must link to something that survives the deletion* is verified by re-classifying every row against that test — not by confirming `Research Pages` is non-empty, which every unrepaired row already was. Re-run the query that produced the worklist; the rows that come back are the ones still to do — **unless the pass leaves some of them rightly unfilled**, as item 12's purpose tag does, where the worklist file is what the verification runs against and a row examined and left blank counts as done (§0, item 12). Expect that set to be empty where the worklist was counted before the batch began (*Reading a whole table*, above), and treat a row in it that the worklist should have held and did not as evidence the count was wrong rather than as a stray — a paged read that dropped four rows drops them from the worklist and the verification alike unless the verification is run against a fresh full count.

**When a write fails:** skip whatever depended on it, continue whatever is independent, and report every success, every failure, and every step not attempted. **A change the pass gives up on goes on the queue** (*Fetch before writing*, above). **Do not retry the same write unchanged in the same pass** — save where the connector rules say how to send it again. One row failing does not stop a batch.

---

