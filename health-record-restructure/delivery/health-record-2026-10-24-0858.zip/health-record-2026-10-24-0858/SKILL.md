---
name: health-record-2026-10-24-0858
description: "Maintain the user's Notion health record across its four databases — Dose, Form and Timing (substance specifications), Health Pages (evidence), Health Pages - Meta (findings the pages cannot hold) and Buying Decisions & Info (what to buy, where, how). Takes a substance, goal, market, photo, link, existing row, or nothing; reads the queue where every chat and pass records what it left unfinished. Produces rows, pages, consolidations, evidence grades and revision histories, brings any page tucked inside a Health Pages entry into the table, and a plain-English report of what was written, decided and left unresolved. Invoked bare, it prints a menu of its jobs and how heavy each is. Use it to evaluate or source products, record or correct a specification, tie specifications to their evidence, settle disagreements between pages, consolidate duplicates, check that nothing is tucked inside an entry, propagate a correction, sweep a database, or audit the whole record. Only load when explicitly invoked by name."
---

# health-record-2026-10-24-0858

**Before reading further, load the connector rules.** Fetch *Working on Notion From Outside: Tested Connector Behaviour* (https://app.notion.com/p/3e110b7903aa8112bb78d0868f8e4cc8) and load its Behaviours rows the way its section *Loading the rules* says: fetching the page alone does not return them. Those rules govern every Notion read and write this skill makes, whichever section you read next, and nothing here restates them; where this skill says *the connector rules*, it means them. If the page or its rows cannot be read, make no Notion write and tell the user why.

**Then load the standing instructions, which override this document.** Query *Health Skills — Standing Instructions and Fixes*, data source `collection://402551d0-e3ea-4ce2-bff6-787e34074628`, in rows mode for every row whose `Status` is `Open` and whose `Instruction` is not empty, read complete as the connector rules read past a row limit. Each such `Instruction` is the user's own — a decision of theirs, or a fix they approved — that these rules do not carry yet. **Where one disagrees with anything in this document, it governs** on the point it names, even over the rules said below to override everything else, though a page's own note can hold it back on that page (§7, *A page's own note to these rules*); one that names the rules it applies under binds only those, and none changes the connector rules. **What the user says in this chat governs both**, save the acts a rule below says their word does not unlock: where it contradicts an instruction in force, follow the user and ask whether that instruction still stands. Before every write, require the complete text of the standing instructions and the complete connector rules in current model input. Retained full text needs no reload, including after compaction; otherwise reload the missing rules before writing. Summaries and prior-loading claims do not suffice. If the standing instructions cannot be read, make no Notion write, and tell the user why and that any answer meanwhile is given without them. How a decision of theirs meant to hold from now on is recorded, and what to try when the data source fails, are in §2, *🛠️ Health Skills — Standing Instructions and Fixes*.

A reference, not a procedure. Find the section that answers the question in hand, and the sections the table under *What you are probably being asked* says the task also owes, and read only those. Nothing here assumes you have read what comes before it.

**These rules are several files; this is the one every run reads first.** It holds the opening above, the table under *What you are probably being asked* and the rules that follow it, §0's upkeep, §1, §11 and *Revising these rules*; every other section is in a reference file named in the table of files below. **Open a file when the table under *What you are probably being asked*, or a pointer, names a section it holds, and leave it closed otherwise.** A pointer of the form §N, *Title* names a section and a subsection wherever it stands; the table of files says which file holds that section. *This document* and *these rules* mean all of the files; *the opening* means the start of this one.

| File | What it holds |
|---|---|
| `SKILL.md` | the opening; *What you are probably being asked*; §0, *Every run leaves the record better organised than it found it*; §1; §11; *Revising these rules* |
| `references/menu.md` | §0 What to run, and what it costs — its opening paragraphs, *What to print — the exact words* and the menu block |
| `references/items.md` | §0 — the numbered items, *Item 20*, *Item 22*, *Band A*, *Band B*, *Band C* and *Band D*, with *Before any of this has ever been run* and *When a heavy pass is actually due* |
| `references/record.md` | §2 Where things live, and the shared vocabulary |
| `references/buying.md` | §3 Buying Decisions & Info — the properties the record writes; §4 The verdict scale |
| `references/evaluating.md` | §5 Evaluating a product; §6 Sourcing from a market |
| `references/research.md` | §7, its first part: *Finding what exists*, *Substance-level against product-level*, *Writing a page*, *Editing an existing page*, *What the record never holds*, *A page's own note to these rules*, *Grading `Evidence`, and the citations under it*, *How much of each source was read*, *Recording a compounded or made-to-order product*; §8 Health Pages - Meta |
| `references/changes.md` | §7, its second part: *Consolidating pages*, *Revisions: the chain of edits*, *What each kind of change makes possibly wrong*, *A correction does not stop at the page it fixes*, *Classify before writing* |
| `references/sweeps.md` | §9 Sweeps |
| `references/writing.md` | §10 Writing mechanics |

**A row of the table under *What you are probably being asked* applies whenever its situation arises, not only as the opening ask**: a run that meets one part-way through another task — a read that turns into a write, a finding that changes something recorded, a fact the user states — opens that row's files. **A run that reads or writes any table of the record opens `references/record.md`**, whether or not its row names §2. **A file is reopened whenever a task needs it and its text is no longer in view** — this file included, which a compaction cuts to its first part, while a reference file read earlier is not in view. In view means in the conversation now; having read a file earlier, or a summary of it, is not.

---

## What you are probably being asked

**Two columns answer each ask, and the second is the one that gets skipped.** *Where the work is done* is the section that performs the task. *What the task also owes* is the set of obligations it incurs by being that task — rules that live elsewhere, that a run reading only *Where the work is done* can miss. **Read both.** Every row that ends in a write also owes §1 and §10; every row whose write cites a source also owes §7, *How much of each source was read*; every row that touches Buying Decisions & Info also owes §3.

| The ask | Where the work is done | What the task also owes |
|---|---|---|
| Nothing named, or "what can you do?" | §0 The menu | nothing else |
| "Is this bottle any good?" — a photo, a link, a name | §5 Evaluating · §4 Verdicts | §3 · §7 *Finding what exists* · §7 *Substance-level against product-level* · §7 *Writing a page* · §1 · §10 · §0 *Every run leaves the record better organised than it found it* |
| "Find me X in country Y" | §6 Sourcing · §5 · §4 | §7 *Finding what exists* · §3 · §1 · §10 · §0 *Every run leaves the record better organised than it found it* |
| "I need something for goal Z" | §6 (substance selection first) | §2 the `Works For` vocabulary · §7 the ladder · the same as the row above |
| "What do I already have on X?" | §7 Finding what exists · §2 Where things live | §0 *Before any of this has ever been run* |
| "Should I record the ones I rejected?" | §6 *What gets a row* | §3 · §4 |
| "Is this shop any good?" · "is this price-comparison site any good?" | §4 *On a seller* · §4 *On a tool* · §5 | §3 *The kinds of row* · §1 · §10 · §0 *Every run leaves the record better organised than it found it* |
| "Is this brand any good?" · "does this maker lie about doses?" | §4 *On a brand row* · §5 | §3 *The kinds of row* · §1 · §10 |
| "Which shop is cheapest for X?" · "compare the prices" | §3 the listing rules, the price rule and *`Price Per Amount`* · §6 *Reaching a recommendation* | §4 *On a listing, the verdict is the product's* · §10 *Updating an existing row* |
| "How do I get X in country Y?" · "do I need a prescription for it there?" | §3 *The kinds of row* — the access rule · §4 *On an access rule* | §6 *What gets a row* · §1 · §10 |
| "What would it cost to have X done at a clinic?" · "should I buy the vial and have someone inject it?" | §3 *A treatment someone else administers is not one row* · §4 the reading for each kind | §3 *A price is written in the row's text, with the date it was checked* · §3 *`Price Per Amount`* · §6 *Reaching a recommendation* · §1 · §10 |
| "Fix / sweep / check these rows" | §9 Sweeps | §3 · §7 Revisions · §2 the scoreboard · §0 *When a heavy pass is actually due* · §1 for the report · §10 |
| "Which use-case tag applies?" | §2 The `Works For` vocabulary | §1, if the answer is that none does |
| "What is this product good for?" · "which of my purposes does it serve?" | §4 *The purposes a product is judged for* · §4 *A product's verdict* | §3 · §1 · §10 |
| "What dose, which form should I insist on?" | §2 Dose, Form and Timing · §5 steps 1–2 | §7 the Meta query · §7 *Finding what exists* |
| "Is this recorded fact right?" | §7 The research record · §8 Meta | §7 *A correction does not stop at the page it fixes* · §10 |
| "These pages disagree" | §7 *Classify before writing* | §7 *A correction does not stop at the page it fixes* · §7 *Revisions: the chain of edits* · §7 *Finding what exists* · §0 *Every run leaves the record better organised than it found it* · §8 · §10 |
| "These are the same page" | §7 Consolidating | §7 Revisions · §10 |
| "Tie the specs to the evidence under them" | §0 items 6 and 13 | §7 *Grading `Evidence`, and the citations under it* · §7 Revisions · §7 *What each kind of change makes possibly wrong* |
| "Why does this say what it says?" · "did we already decide this?" | §7 Revisions · §10 *Updating an existing row*, where it is a verdict | §8, if the answer is that it is contested |
| "I have too many pages saying the same thing" | §0 items 17 and 18 · §7 Consolidating | §10 *Writing a synced relation across many rows* |
| "I found a new fact — where does it go?" | §7 Writing a page | §2 *Every research page is a row* · §10 |
| "The page I need is kept inside another page" · "this page has no fields" · a page pasted in by hand that landed inside an entry | §2 *A page found beneath a row comes up* | §2 *Every research page is a row* · §2 the queue · §1 for the report |
| "Which of these are my own notes?" · "skip my journals" · "I ticked Ignore on this page" | §2 *Every research page is a row* — the `Ignore` flag | §7 *What each kind of change makes possibly wrong* — the `Ignore` row, where anything cites the page · §1 |
| "Leave this page's limits as they are" · any ruling the user means for one page only | §7 *A page's own note to these rules* | §1 · §10 |
| "I added some entries myself" · "bring in what I added by hand" · a bare "22" | §0 item 22 · §2 *`By hand`* · §0 item 4, for entries not ticked | §7 *Finding what exists* and *Classify before writing* · §1 for the report, and for the third of the four · §10 |
| "What used to sit under this page?" · "where does this page belong?" | §2 *Every research page is a row* — `Child of` and `Parent of` | §10 *Writing a synced relation across many rows* |
| A fact that changes something already recorded | §7 Revisions | §7 the fan-out · §8, if the change is contested rather than settled |
| "Catch up" · "what is outstanding?" · "did that ever get done?" · a bare "20" | §0 item 20 · §2 the queue | §7 *What each kind of change makes possibly wrong* · §2 on `Weight` and `Status` · §0 the upkeep every run owes · §1 |
| "They discontinued it" · "that study was retracted" — a fact about a product or the research, stated, nothing edited | §7 *What each kind of change makes possibly wrong* — its row for the user stating a fact, and the paragraph under the table | §7 the fan-out · §2 the queue · §10 · §1 · record what they said before fanning out |
| "I take 400 now" · "I stopped that" · "I've ruled it out" — the user's own use | §2 *The user's own use is out of bounds* | §1 for the answer |
| "From now on…" · "always…" · "never…" — how the record is to be kept or judged | §2 *🛠️ Health Skills — Standing Instructions and Fixes* | §1 · §10 |
| "I moved some pages about" · a page deleted, dragged beneath a page, or moved up from beneath one | §2 *Every research page is a row* and *A page found beneath a row comes up* · §7 *What each kind of change makes possibly wrong* | §0 item 14 · §2 the queue · §1 |
| "Check nothing is kept inside an entry" · a bare "21" | §0 item 21 | §2 *A page found beneath a row comes up* · §10 *Order of writes* for the scope row · §1 |
| "Delete this page" · "get rid of the duplicate" · "that one is superseded" | §1, the deletion marker | §7 *Consolidating pages*, where it repeats another · §2 the queue · §1 for the report |
| "Copy this page" · "leave a note on it" · "make me a view for that" · "attach this photo" | §10 *What else the connector offers, and what is done with it* | §1 for the report, and for the first of the four where the ask is a copy · §3 where the file lands on a product row |
| Anything ending in a write | §10 Writing mechanics · §0 the upkeep every run owes | §1 — the report · §11 · §7 *How much of each source was read*, where it cites a source |
| "Should I be taking this?" · anything that reads as treatment advice | §11 | §6 *Reaching a recommendation*, for where clinical context goes |
| A number from the menu — "7", "run 13", "17 and 18" | §0, the item's own note (`references/items.md`) | the sections that note names, and this table's row for the ask the item performs · §0, its opening paragraphs (`references/menu.md`) · §1 · §10, where it writes · §0 *Every run leaves the record better organised than it found it* |

**Two rules about this document's own text.** **A cross-reference names a section and a subsection title and says nothing about what the rule contains**: a gloss on a pointer is a second copy of the rule, kept where nobody will update it, and it will be trusted. And **never write the number of members of a list that can grow** — *the routes below*, not *the five routes* — because the count goes stale the first time the list does.

**The substance facts and the row counts used as examples in this document — which form of a substance is required, how big a database is — were true of the record when written and are examples, not a second copy of it. The record is authoritative.** **A count here illustrates a shape and is never a figure a run quotes on its own**; item 1 takes the live ones, and the menu prints what the scoreboard supplies. Where the two disagree, judge by the record, say in the report which example here now conflicts with it, and write a row for the conflict as a place these rules ran out (§2, *🛠️ Health Skills — Standing Instructions and Fixes*), because this document cannot edit itself and the next run will read the example (§11).

**Every run, whatever it was asked for, finishes with the upkeep in §0**.

**Anything that leaves something unfinished in the record says so in the queue** (§2), as one row naming what would clear it and carrying a `Weight` saying what finishing it would cost. **That holds whoever left it** — an ordinary chat, or a numbered item that ran out of room — which is why there is one queue and no rule deciding where a leftover goes. **A fact the user states about a product or the research that no edit recorded is not a leftover at all and still goes there**, under `user changed the facts`, whatever item is running: it is a change made by them rather than unfinished work by the run, and until it is written down nothing in the workspace holds it. **One about their own use goes nowhere** (§2, *The user's own use is out of bounds*). The queue is what stands between the next maintenance pass and reading the whole record again, and reading is what a maintenance pass costs. **It sees only the rows written into it.** An edit the user makes in the Notion interface leaves no row, so a pass that wants the whole picture pairs the queue with items 22 and 4 (§0), which find edits nobody logged.

**Everything the user reads is in plain English, and none of the vocabulary in this document is plain English** — not `Sources`, `Must Agree With`, `Works For`, *spec row*, *rows mode*, *relation*, *band C*, *Meta*. §1 has the rule and §0 has the menu it applies to hardest; it holds for every report and every answer, from whichever section a run was routed through. **It does not run inwards**: what gets written *into* the record uses the record's own vocabulary, because the next run is what reads that.

**Four rules cross every task, live in §7, and are the ones a run is likeliest to miss.** They are stated here for that reason; §7 carries each in full.

1. **Before writing any verdict that rests on a recorded specification, query Meta for its unsettled rows on that substance, and the queue for outstanding rows naming it** (§7 runs the two together) — two filtered reads, and the last moment at which finding out is free. **That Meta query has a fallback and it is not optional**: the audit that tagged the pages filled `Substances / Topics` on every Meta row then standing, and item 16 fills a row that has none when it sweeps — but no whole-database pass maintains it between those sweeps, so a row written since may have none and an empty result may be an empty field rather than an absent row. **The queue half needs a fallback too, and a cheaper one**: `Substances / Topics` on a queue row is filled by whoever wrote it and nothing enforces it, so where that alias query comes back empty, read `What` across the outstanding rows, taken as item 1 takes them (§7). What to do with what the Meta read returns is §4, *When the specification itself is in question*.
2. **A family is not a substance, and a search is only as wide as its alias list.** Magnesium, alpha-lipoic acid and B12 each cover several salts, isomers or vitamers; search the family name and every form, in every language the record might have used, not the one name the user said. A market screened on three forms against a record searched on one is the commonest way a page is missed.
3. **A new page is the last resort, and the candidate page's own `Revisions` section is read before any branch but the last.** Take the first branch that applies: a page holds this and is right, a page holds it and is wrong, several pages hold pieces of it and say the same thing at the same scope, nothing covers it. Creating a page beside one that should have held the finding is invisible afterwards, because both pages then look complete. §7, *Writing a page*.
4. **A correction does not stop at the page it fixes.** Several routes fan out from it, and a corrected page sitting above rows that still argue from its old claim is the worst state this workspace can reach (§7, *A correction does not stop at the page it fixes*).

**Some further rules override everything else in this document and are repeated where they bite:** every research page is a row — a page found kept beneath one comes up on sight, a chat never creates one there, and a link never lands on a container as a stand-in (§2, *Every research page is a row*); a row ticked `Ignore` is the user's own note and outside every job (§2); and never writing a page against a copy that could have gone stale (§10).

---

## §0 What to run, and what it costs — the upkeep every run owes

The rest of §0 — its opening paragraphs and the menu, and the numbered items — is in `references/menu.md` and `references/items.md`. This subsection stands here because every run owes it.

### Every run leaves the record better organised than it found it

**This is what keeps band D rare, and skipping it is what makes band D necessary.** Whatever a run was invoked to do — **including a band A or B run routed here from §5, §6 or §7, which is where this is most often skipped** — before it reports it does the following, **on the pages it actually opened and compared, never on a set it merely listed** — and never on a row ticked `By hand`, which is brought in whole or left as it is (§2, *`By hand`*):

- **Tag what it read.** A Health Page *row* it fetched gets the `Substances / Topics` it lacks — the field filled where it is empty, and the names the page has just started needing added to what is already there, read first — and `Works For` where the page states its purpose. The fields are on the page it already has open. **A row ticked `Ignore` gets neither** (§2): it is the user's note and is left as it is. **A page found kept beneath a row comes up first** (§2, *A page found beneath a row comes up*) and is then tagged as a row.
- **Link what it compared.** Two Health Page *rows* it actually classified against each other (§7) get a `Must Agree With` between them. **Never to or from a row ticked `Ignore`** (§2), and **a page found kept beneath a row comes up first** and the link is written to it — never to a container as a stand-in. **Only pages it compared** — not every pair it happened to read, which is unbounded and mostly meaningless. **Outside the items built to write it, little but this ever does** — §7's own writes on a new page, on a consolidation, and wherever a correction's search turns up a page that should have been reachable and was not — and every edge left behind is one item 17 does not have to find.
- **Source what it grounded.** Where the run used a page as the stated ground for something in a spec row, that page is added to the row's `Sources`. **A page that was merely open is not a ground.** **Never a row ticked `Ignore`** — a note is not a ground, whatever it says (§2) — and **a page found kept beneath a row comes up first** and `Sources` points at it; the row that contained it is never written in as a stand-in. **Where the spec row had no `Sources` before**, what that makes possibly wrong (§7, *What each kind of change makes possibly wrong*) goes on the queue under `specification moved`.
- **Fix a description that describes a different page.** A run holding a page's body and its `Description` side by side is at the one moment the mismatch is visible, and `Description` is a field a search matches on, so a wrong one changes which pages come back rather than merely misleading a reader. **Never on a row ticked `Ignore`** (§2). **Writing a description for a page that has none is not this and belongs to item 12**: it means reading the whole page, and one derived from the title restates the title. **The exception is a page this run has already fetched in full and edited** — the body is in hand, the reason is spent, and the description is written from it and read back (§2, §10, *After writing*). A new page and a page brought up are different: each is given one as it is written or brought up (§7, *Writing a page*; §2, *A page found beneath a row comes up*).
- **Say the rest.** Anything noticed and not fixed goes in the report, and — unless it is a gap item 1 counts — onto the queue under `noticed not touched` (§2, the queue), or into Meta where §8 admits it; a disagreement goes under `contradiction spotted` instead, beside its Conflict in Meta where §8 admits one, and two pages found to hold the same claim at the same scope under `pages became one`.

**Three limits, and they are what make this safe rather than a second run bolted onto the first.** Every one of these is a write, so **each obeys §10 in full** — and `Sources` and `Must Agree With` are relations and `Works For` a multi-select, each written the way the connector rules write a list. **Cap it at roughly ten pages** — past that, say what is left and name the item that covers it — 12 for tags, 13 for sources, 17 for links — or say the remainder is unclaimed where none does, a `Sources` added to a row that already had some, and a name or a purpose added to a page that already carried some, being such cases. **A page found kept beneath a row is not tidying and is not capped**: it comes up whenever it is found (§2), and where a run finds several it brings them all up and names the fact for item 21, whose next run is then the check that none were missed. **This caps incidental tidying only.** Where the run's own purpose is the thing on this list — item 12 tagging, items 6 and 13 sourcing, items 9 and 17 linking, item 21 bringing pages up, item 22 bringing rows in, and item 20 wherever a queue row's own catch-up is one of them — its scope bounds it and the ten does not apply; and a run of item 21, clean or not, which fetched bodies only to look for sub-pages, tags none of the rows it opened. And **never write to a page returned by a workspace-wide search without checking what it is** (§2).

**None of this needs research**, which is the point: the reading is already done and the judgement is already made. **None of it earns a `Revisions` line or an `Edits` line either** (§7, §10) — it adds information and moves no claim, and it removes nothing. **Beyond the queue row a first `Sources` takes (*Source what it grounded*, above), the report is the only trace the tidying itself leaves**, so it is named there — in the user's words, not the record's (§1). *I added search terms to four research pages so they can be found by name next time.* *I linked two pages that must not disagree, so a correction to either one will find the other.* *I recorded that one page is the stated basis for the magnesium line.* Never *tagged with `Substances / Topics`*, never *wrote a `Must Agree With`*, never *promoted*, never *did the upkeep*. **Say how many pages and say what changed on them**: a closing report naming no writes at all claims a read-only run, which is the thing this paragraph exists to prevent.

---

## §1 What this skill decides on its own

**Ask the scope questions before research, never after.** The questions below decide what gets researched, so asking them late means researching the wrong thing.

Before starting, these change the entire answer and cannot be safely guessed:

- **Which market.** A product set for Mexico and one for Germany share almost nothing. If no market is named and none can be inferred from what the user said, ask.
- **Which substance, when only a goal is named.** Where a stated goal maps to two substances with different evidence, ask which. Where it maps to one, or to a protocol the pages document, do not.
- **Scope, on a sweep.** "Sweep the database" is not a scope. Name the subset and confirm it before reading — except where the item chosen names its own scope (§0).
- **What a product is wanted for**, where neither the request nor the research in hand makes it plain — with nobody to answer, a marked guess (§3, `Intended Purpose`).

After research begins, decide. Every judgement below belongs to this skill and is not a question:

- Which products survive screening, and which get evaluated deeply.
- Every verdict — a product's lists, `Not good for` included, its box and its `Dose check`, and a brand's or a tool's `Decision`; a seller's only where §4, *On a seller*, allows one; and overwriting one the user set personally, against evidence that has not changed, stops and asks (the third of the four, below). **A purpose with several parts is several purposes** (§4, *The purposes a product is judged for*), and only where what the parts are is unclear is it a question.
- Whether a row is created, updated, or converted from one type to another.
- **Which kind of row a thing is** — a product, a listing of it, a maker, a seller, a tool or a market's access rule (§3, *The kinds of row*).
- Whether a finding changes a Health Page, creates one, consolidates several, changes a spec row in Dose, Form and Timing, or becomes a Meta row. **Which of those is right is not a free call** — §7 sets the order, and a new page is the last resort in it.
- Which product to recommend, and on what axis.

**When two candidates cannot be separated, put them at the same tier and say what differs.** One dearer with better documentation and one cheaper with less can carry the same lists; the difference goes in `Why` as an axis and the price comparison goes where a price goes (§3, *A price is written in the row's text, with the date it was checked*). Ranking is not a verdict.

**Report after writing, do not propose before it.** Show what was written, what was decided and why, what could not be established, what was deliberately skipped, what is now waiting on the queue and what clearing it would take — put as one question, whether to do it now, where it is heavy catching-up a chat wrote there (§2, the queue) — and **what is now the user's to do or to decide** — a page or row only they can delete, an entry only they can take out of a list of links, text of their own to log, a page worth ticking, a market they may want gone, a column a value needs that one of their tables does not have, an earlier recommendation this run could not reach. **Those are the user's to act on**, so they are named one by one rather than summarised. The user overturns anything in that report; that is cheaper than blocking on approval, and it is what they asked for. **And where these rules ran out — a case they do not cover, a rule that gave the wrong result — say that too, with the fix you would suggest, and name the row written for it, or what it would have said where it could not be written; and name any decision of the user's recorded as a standing instruction** (§2, *🛠️ Health Skills — Standing Instructions and Fixes*). Those are the part of the report about this document rather than the record, and a suggested fix binds nothing until the user approves it. **The exceptions are items 20 and 22**, which report what is outstanding or waiting to be brought in, price it, and ask how far to go before they write anything, item 22 named with one row excepted — because that price is the whole of what they are choosing between, and because an item that decided it for them would be deciding the one thing they are there to decide (§0). **And so is any item the user asked, as they picked it, to show before it writes**, which the menu offers them.

**Everything the user reads is in plain English, and this document's own vocabulary is not plain English.** `Sources`, `Must Agree With`, `Works For`, `Source For`, spec row, rows mode, multi-select, relation, band C, Meta — every one of those is a name for something in here, and none of it means anything to someone who has been away six months. **Where a term genuinely has to appear** — the user asked about a field by name, or the report is telling them where to click — **explain it the first time it appears in that reply**, not the first time it appeared three replies ago. This holds for the menu (§0), for a run's closing report, and for every answer in between. **The rule does not run inwards**: what gets *written into the record* uses the record's own vocabulary, because that is what the next run reads, and a `Description` written to be searched is written for the search, not for the reader.

**And it is laid out for reading, never as one block of prose**: a heading for each part of a reply that has several, a bulleted list wherever it names more than two pages, rows or changes, short paragraphs, and bold only for what the user has to decide or act on. The menu (§0) is printed as it stands.

**The substitutions are fixed here rather than left to the moment of writing:**

| In the record | In anything the user reads |
|---|---|
| `Sources` | the research pages that line is based on |
| `Must Agree With` | linked, so a correction to one finds the other |
| `Source For` | the substance lines built on this page |
| `Substances / Topics` | the names a search can find that page by |
| `Works For` | what it is for |
| `Evidence`, `Not assessed` | how good the evidence is; never graded |
| `Decision` | the verdict — on a maker, whether it is honest about doses; on a site for finding or checking, whether it does its job; on a shop, yours, unless it has a name for selling underdosed or fake products; on a product, the older verdict it carries until it gets the new one |
| `Works for` · `Might work for` · `No benefit shown for` · `Not good for` | as they stand — what it works for, might work for, has not been shown to help with, is not good for |
| `Not good for anything` | not good for anything, whatever you want it for |
| `Dose check` | whether anything independent has confirmed how much is in it |
| `Met Intended Purpose` | the old verdict on whether it fits what you wanted it for |
| `Item Type` | what kind of entry it is |
| `Specific Product` · a listing | a thing you can buy · one shop's listing of it |
| `Seller` | a place to buy it |
| `Tool` | a site for finding or checking |
| `Access Rule` | how you can get it in that country |
| `Availability` | where you can get it |
| `Discontinued` | no longer made anywhere — of a shop or a tool, no longer operating |
| `Price Per Amount` | what it costs per amount — per milligram, or per capsule, say |
| `Can be acquired without a prescription in one or more countries` | where it has been found sold without a prescription |
| `Edits`, `Revisions` | the note of what changed and why |
| `Current` | the pages you have ticked as ones you are working in |
| `Description` | the page's summary |
| Meta | the short list of things the pages cannot tell you |
| a spec row | a substance's line |
| a Health Page | a research page |
| the queue | the list of loose ends |
| `Weight` | how much work it would take to finish |
| `Priced not taken` | priced and turned down |
| `Kind`, on the queue | what sort of loose end it is |
| `Open` · `Done` · `Examined not cleared` · `Cannot be cleared`, on the queue | awaiting its turn · finished · got part-way and stuck · nothing could finish it |
| a page kept beneath a row · a child page · a sub-page · a nested page | a page tucked inside a table entry |
| moving a page up · promotion | moving a page up into the research table — same page, every link to it still working |
| `Ignore` | Ignore, by its name — *a page you ticked Ignore*, *the Ignore flag* — never a paraphrase of it |
| `By hand` | the tick for anything you added or changed yourself that is not yet tied into the rest of the record |
| `Child of` · `Parent of` | which entry a page sits under · which pages sit under an entry |
| the census · item 21 | the check that nothing is tucked inside an entry |
| the flattening | the day the pages then tucked inside entries were moved up into the table, 13 September 2026 |
| the deletion marker | *Duplicate or Superceded - DELETE ME* at the front of a title, so that one search finds everything waiting for you to delete it |
| the receipted `Sources` swap · a stand-in dropped | that line used to point at the entry this page sat inside, because it could not point at the page; it now points at the page itself, and I noted the change on the line |
| demotion · dragging a row beneath a page | a table entry dragged inside another page, which hides its fields |

**Rows mode, relation, multi-select, synced twin, band A to D, the upkeep, the fan-out, revert, idempotent, promote, re-parent, stand-in — these never appear in anything the user reads, in any form**, including paraphrased into a longer sentence that still describes the mechanism rather than the effect. **Read the report back before sending it**, looking for backticks, capitalised field names, and the word *row* where *line* or *page* is meant.

**Four things are not reversible by editing a field. Two of them stop and ask. The other two are never done at all, and asking about them is not one of the options: deleting a row or a page — dragging one down beneath a page, duplicating one and moving a table included — and the destructive half of a schema change.**

1. Deleting a row or a page — and dragging a row down beneath a page, which hides its fields and links the way a deletion would (§2, *A page found beneath a row comes up*) — **and duplicating one, which belongs on this list for exactly the same reason: undoing a duplicate is a deletion, so it cannot be undone here** (§10, *What else the connector offers, and what is done with it*). **A yes does not unlock this** — the menu promises the user that nothing here ever deletes, and §7 and §9 both leave the act with them. Name the page or row in the report as one they could delete, copy or move themselves, with what the act would cost them beside it, a deleted page taking every mention aimed at it with it; log the request under `asked for not done` (§2, the queue), and stop there. **A page or row awaiting their deletion is marked**: once anything only it holds has moved to the one that stays, its title takes the prefix `Duplicate or Superceded - DELETE ME — `, in the user's own spelling so that one search finds every such page, and the report names it; throwaway test pages keep the connector rules' `DELETE ME — …` titles. (Moving a page *up* into the table is the opposite act, destroys nothing, and is this skill's to make — §2.) **A table moved or re-homed, or its rows moved into another table, is on this list too**, named in the report for the user and logged the same way.
2. Changing a schema destructively — **removing or renaming an option, removing a property, renaming one, retyping one**. What each of those does was measured rather than assumed (the connector rules). **A yes does not unlock them, and they are not asked about mid-flow.** **Adding an option is the exception and is this skill's to make**: a value a select or multi-select has no option for is added, on the conditions in §10 and named in the report, because a market or a use that cannot be tagged is written in prose where no filter reaches it. **Adding a property is not**: nothing here adds one (§10, *Check every schema before the first write*).
3. Overwriting a verdict or an `Evidence` grade the user set personally, against evidence that has not changed. **A verdict or grade the user entered or changed by hand is theirs as a fact** — the row still ticked `By hand`, or carrying the *by hand* line that bringing it in writes (§2, *`By hand`*) — and elsewhere the older test decides: a row whose body carries neither the verification callout (§10, *The verification callout*) nor, on an older row, a *Researched* date, and whose `Edits` — on a spec row, whose `Revisions` section, that table carrying no `Edits` (§10) — carries no line of this skill's is the user's own, and so is any verdict or grade an `Edits` line, or on a spec row a `Revisions` entry, records them directing.
4. A schema that has drifted so far that where a value goes cannot be established — the narrow case set out in §10, which is a different thing from the changes the second of the four governs.

**Never ask about dose.** State the arithmetic instead — that is a format observation, not a dosing question. **That is not the same as establishing which of two things a figure they named was** (§7, *What each kind of change makes possibly wrong*), which is asked. **Never send the user on an errand** — never ask them to contact a company, chase a manufacturer, or go and find something that is not already in their hands. **That is not the same as §5, *A document only the user has*.** **Never ask anything a search would answer.**

---

## §11 Notes

Verdicts are about what a product does for a purpose and whether it can be trusted, not about whether the user should be taking something. Dose and treatment decisions belong with their doctor. State this once if relevant; keep it out of the rows.

Write in plain, direct English. When something is uncertain, say so rather than dressing it up. **This document cannot edit itself.** Where a rule here turns out to be wrong, a figure here has been overtaken by the record, or a case arises that none of this covers, say so in the report — **and write the row the standing instructions keep for it** (§2, *🛠️ Health Skills — Standing Instructions and Fixes*), which is what makes the improvement durable rather than something that lives in one reply.

## Revising these rules

**Whoever revises these rules reads every row of the standing instructions first** (§2, *🛠️ Health Skills — Standing Instructions and Fixes*), and, once the user has put the revised text in use, sets each row it carries to `Fixed` — or a fault it finds needs no change to `Not a defect` — with a dated line in its `Detail` naming where the text now says it. A row left `Open` with an `Instruction` stays in force, so a revision that carries an instruction without closing its row leaves two copies of one rule to drift apart.

Revised: 2026-10-24.
