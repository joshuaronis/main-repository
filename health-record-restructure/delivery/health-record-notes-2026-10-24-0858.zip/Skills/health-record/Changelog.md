# health-record — changelog

One entry per release, newest first: the version before and after (the md5 of each file — until the 2026-10-24-0858 release `SKILL.md` was the skill's only file), what changed in what a run does, why, and the release. Josh's words are in `Skills/health-record/Decisions and do-not-fix.md`, and what each change taught the next editor is in `Skills/health-record/Lessons.md`. Add to the top; correct an entry with a dated note beneath it.

Until 2026-10-13 this was `History.md`, which also recorded each job's edit labels, pass and fail counts and working-file paths; it was condensed into this file that day.

## 2026-10-24-0858 — a short main file plus reference files

- **Version**: `SKILL.md` `267a832da408ed34ede1abd289e94645` (one file, 445,267 bytes) → ten files: `SKILL.md` `a559cab3d323e7fe85189c9a61577d1d`; `references/buying.md` `eadcc3a60fc555596fddc4dac44aa3b5`; `references/changes.md` `ab5d08323e32197a16f704e2b6f86441`; `references/evaluating.md` `1da274e988cc224f84188b5f0ffee200`; `references/items.md` `89e4f8e2630dec0c81e3459079d1ebbd`; `references/menu.md` `bb9cf460566490d0e12641c355c03fbb`; `references/record.md` `156a56249773f6a1e253823571b9b3f2`; `references/research.md` `478e8f160a4c6a348878205d28eca14f`; `references/sweeps.md` `7fb02c39ceb0bfb23f8e0f62b12bb950`; `references/writing.md` `b8d4c0c96b1ab4fdb792506ae28dd851`. 441,536 → 464,753 characters in all; footer `Revised: 2026-10-24.`; the name, folder, zip and title stamped `health-record-2026-10-24-0858`.
- **Changed**: the layout only. `SKILL.md` keeps the opening, the routing table and the cross-task rules, §0's upkeep, §1 and §11, and gains a files block, a table of files, a rule to reopen a file whose text is no longer in view, and a routing row for a number picked from the menu; every other section moved whole into a reference file (`Skills/health-record/About.md` has the table), cut at section boundaries, every line byte for byte, save twenty-seven pointers rewritten where a cut parted them from their target (nine in §0, fifteen in §7, three elsewhere) and one reason clause in §2 that rested on the whole skill being one loaded text. A run following a routing row now loads on average 47% of the one-file text, against all of it before; the table by route is in `Skills/health-record/About.md`.
- **Why**: Josh, 2026-10-24 (`Skills/health-record/Decisions and do-not-fix.md`): a chat should load only what its task needs; his test that reference files load only when opened was done before and not repeated.
- **Release**: `health-record-2026-10-24-0858.zip`; not yet uploaded to claude.ai.

## 2026-10-24 — connector behaviour left to the connector rules

- **Version**: `ade726d9187a13c093913932a82ef512` → `267a832da408ed34ede1abd289e94645`; 447,075 → 445,267 bytes, 1,669 lines; footer `Revised: 2026-10-24.`
- **Changed**: statements of general Notion and connector behaviour are gone, cited or not: what a query returns of a body or of a page kept beneath a row, that a search is capped and silent about it, which changes leave last-edited time where it was (the menu's example included), whose name a connector write or a comment carries, two writers overwriting each other, what a body write drops, that a relation write replaces the whole list or reads back whole, how a fetched path shows a column layout, what a two-way relation adds to the other database, how a view reads. The record's own facts and rules stay, and so do the pointers to the connector rules that were there. A report says whether writes were *written* or *verified* (was "issued, or verified"); only re-running the check that motivated them verifies them. The opening: before every write, the standing instructions and the connector rules must be in the conversation whole; full text still there needs no reload, even after compaction, and a summary is not enough (carried in from ChatGPT's copy, below, naming the standing instructions where it said "their" and "they").
- **Why**: Josh, 2026-10-23: general connector behaviour belongs only on the connector page, and nothing points to a rule it doesn't hold yet (`Skills/health-record/Decisions and do-not-fix.md`). What the page doesn't hold went into a prompt for a session that tests it there.
- **Release**: `health-record 2026-10-24.zip`; installed in `~/Desktop/Skills/health-record/` and uploaded to claude.ai by Josh on 2026-10-24.

## 2026-10-24 — ChatGPT's copy, changed outside this folder

- **Version**: `0fdd60310f5f5a4f0831b9b2114e1105` (the 2026-10-13 release) → `07410f3721c94345604d4554f837c736`, found in `~/Desktop/Skills/health-record/SKILL.md`; no release zip, since the 2026-10-24 release carries its change.
- **Changed**: one sentence of the opening, "Load them and the connector rules again after any compaction, before the next write.", became "Before every write, require their complete text and the complete connector rules in current model input. Retained full text needs no reload, including after compaction; otherwise reload the missing rules before writing. Summaries and prior-loading claims do not suffice."
- **Why**: not known; it matches Josh's preferences on when to reload the connector rules. Josh, 2026-10-24: «Carry it in».

## 2026-10-23 — connector typing and checks left to the connector rules

- **Version**: `0fdd60310f5f5a4f0831b9b2114e1105` → `ade726d9187a13c093913932a82ef512`; 446,479 → 447,075 bytes; 1,678 → 1,669 lines; footer `Revised: 2026-10-23.`
- **Changed**:
  - Connector typing is the connector rules': a mention is written "in the form the connector rules give for a page mention" (separator, parenthetical and no-self-mention rule unchanged); a sub-page and a mention are told apart by what they are; a `Revisions` entry's nested lines and a find-and-replace anchor are typed as those rules say.
  - No check the connector page does not owe: no count "before and after" a body write, no fetch after a schema change or before clearing a `By hand` tick; relation counts are labelled as written.
  - A connector behaviour the rules miss goes through the connector page's own procedure; with nobody to answer, the run reports its proposed change and test.
- **Why**: Josh, 2026-10-23, and his three answers that day (`Skills/health-record/Decisions and do-not-fix.md`); the connector's new text format, around 21–22 October 2026, made the `mention-page` form store as broken text.
- **Release**: `health-record 2026-10-23.zip`; never installed.

## 2026-10-13 — how much of each source was read

- **Version**: `e38e00bfc2eb39f8009f20ae888e4d4b` → `0fdd60310f5f5a4f0831b9b2114e1105`; 441,089 → 446,479 bytes; 1,653 → 1,678 lines; footer `Revised: 2026-10-13.`
- **Changed**:
  - A new §7 subsection, *How much of each source was read*: each source a run cites for a claim gets a dated mark (`in full`, tables included; `in part:`; `abstract only`; `through` another source), with `Not reachable:` and `Still to read:`, on its entry in the page's list of sources or after the citation, never inside a `Revisions` entry.
  - Owed reading is done when cheap, else queued one row per page (*Still to read for*); a claim resting only on an abstract or another source's account says so; an unmarked older entry is never taken as read in full.
  - Pointed to from the routing table, §6, §7's *Writing a page* and §10's product-row template.
- **Why**: Josh's request of 2026-10-13, the design left to the editor (`Skills/health-record/Decisions and do-not-fix.md`); in force through standing-instruction row `3f810b7903aa818abe82e34ebff9abfb` until installed.
- **Release**: `health-record 2026-10-13.zip`; installed on 2026-10-14 by Josh on claude.ai («I've uploaded the newest version») and in `~/Desktop/Skills/health-record/` (md5 matched); the row then set `Fixed`.

## 2026-10-12 — own-use notes, dose ceilings, tapering, same-run corrections, the scoreboard count, a guessed purpose

- **Version**: `266690e8cb8a7bb847063c948e27e728` → `e38e00bfc2eb39f8009f20ae888e4d4b`; 438,448 → 441,089 bytes; 1,651 → 1,653 lines; footer `Revised: 2026-10-12.`
- **Changed**:
  - An own-use note on a research row also gets one queue row per page, for a chat that can also write his own history, which logs it at his word and only then removes it.
  - A dose ceiling is a highest amount to take, or one above which harm is expected; levels at which to pause a medicine and a label's titration steps are not ceilings. A plan for the user is his own use (§2).
  - A run corrects its own new text in place before reporting, naming each correction; "a run" is one request in one chat.
  - `Only Might work for` counts product rows, listings included, with only `Might work for` filled and the box unticked.
  - With nobody to answer, `Intended Purpose` takes a best guess marked `(a guess, to confirm)`, one queue row per guess; a guess adds no option.
- **Why**: Josh's decisions of 2026-10-12; standing-instruction rows `3f610b7903aa8194a54ff14cd8a3597f` and `3ef10b7903aa817e82eeda752297e275`.
- **Release**: `health-record 2026-10-12.zip`; installed by Josh on 2026-10-12 («Both skills are installed here»), on claude.ai and in `~/Desktop/Skills/health-record/` (md5 matched).

## 2026-10-11 (2) — follow-on work, purposes, item 14

- **Version**: `b4a3e6caa2f2ed9f28954304b5c4f761` → `266690e8cb8a7bb847063c948e27e728`; 436,476 → 438,448 bytes; 1,649 → 1,651 lines.
- **Changed**:
  - A chat running no numbered item does the catching-up its change calls for wherever it is cheap, queues what stays heavy, puts that to the user once at the end with what each part would cost, keeps a markdown to-do file, and closes its own rows once their work is done.
  - `Intended Purpose` is filled from the user's words or from what the request or the research is plainly about, several allowed, and asked where neither makes it plain; a product is also judged for the user's other purposes its research speaks to (§4, *The purposes a product is judged for*).
  - Item 14 fetches every distinct target; its repair half still writes only to rows of the four databases.
- **Why**: Josh's decisions of 2026-10-11.
- **Release**: `health-record 2026-10-11 (2).zip`; never installed, superseded by 2026-10-12.

## 2026-10-11 — standing alone

- **Version**: `edc45876fc114b9152c564b6ac94c34a` → `b4a3e6caa2f2ed9f28954304b5c4f761`; 443,623 → 436,476 bytes; 1,672 → 1,649 lines; footer `Reconciled: 2026-10-02.` → `Revised: 2026-10-11.`
- **Changed**:
  - The retired sibling, health-record-edits ("the lighter rules"), removed: §2's queue states when a chat running no numbered item clears a row, instead of deferring to it; "a chat under the lighter rules" became "a chat running no numbered item"; the closing overlap section became *Revising these rules*.
  - Health History no longer named or ruled on, its rules being in Josh's custom instructions; the rules on the user's own use stay, "wherever it is found", and own-use wording moved out of a research field goes under *Awaiting logging*.
- **Why**: Josh's decisions of 2026-10-11.
- **Release**: `health-record 2026-10-11.zip`; never installed. Set aside on 2026-10-13.

## 2026-10-04 — the October audit

- **Version**: `9699eecc07b0690434685414c5db18fa` → `edc45876fc114b9152c564b6ac94c34a`; 403,271 → 443,623 bytes; footer `Reconciled: 2026-10-02.`
- **Changed**: the October audit's fixes, under the strict bar after its first cycle (what it judged and kept is in `Skills/health-record/Judged list.md`); among them, listing titles now carry the maker. Nineteen standing instructions the text now carried were set `Fixed` that day.
- **Why**: Josh's request of 2026-10-01 for iterative audits until convergence; the maker in titles is his convention.
- **Release**: `health-record 2026-10-04.zip`; installed on 2026-10-04, with the sibling removed from his account until its own revision. Set aside on 2026-10-13.

## 2026-10-01

- **Version**: `6ae173dbe7f962dbcb1cd38d7644df43` → `9699eecc07b0690434685414c5db18fa`; 399,677 → 403,271 bytes.
- **Release**: `health-record 2026-10-01.zip`. Set aside on 2026-10-13.

## Before 2026-10-01

- **Version**: `6ae173dbe7f962dbcb1cd38d7644df43`; 399,677 bytes.
- **Release**: `health-record before 2026-10-01.zip`. Set aside on 2026-10-13.
